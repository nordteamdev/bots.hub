#!/bin/sh
while true
do
{
            node vr.js
			
			echo "Начинаю перезагружать бота,"
			echo "осталось:"
			for i in 3 2 1
			do
			echo "$i..."
			sleep 1
			done
			echo "Бот перезапущен."
}
done 